//
//  FEBluetoothSDK.h
//  FEBluetoothSDK
//
//  Created by ericj on 2020/5/20.
//  Copyright © 2020 Feasycom. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "FEPeripheral.h"

@interface FEBluetoothSDK : NSObject <CBCentralManagerDelegate>

/// 是否显示调试信息
@property (nonatomic) BOOL isShowLog;
/// 中心管理者
@property (nonatomic, strong) CBCentralManager* centraManage;
/// 搜索到的外设数组
@property (nonatomic, strong) NSMutableArray<FEPeripheral *>* scanPeripherals;
/// 已经连接的外设数组
@property (nonatomic, strong) NSMutableArray<FEPeripheral *>* peripherals;

/// 单例对象
+ (instancetype)sharedFEBluetoothSDK;

/// 搜索
/// @param filtrationBlock 过滤条件（YES:过滤  NO:通过）
/// @param scanBlock 回调（peripheral:搜索到的设备）
- (void)scanFiltration:(BOOL(^)(FEPeripheral* peripheral))filtrationBlock complete:(void(^)(FEPeripheral* peripheral, BOOL isNew))scanBlock;
- (void)scan:(void(^)(FEPeripheral* peripheral, BOOL isNew))scanBlock;

/// 停止搜索
- (void)stopScan;

/// 连接设备
/// @param peripheral 设备
/// @param serverFinishBlock 扫描服务完毕回调
/// @param deviceInfoBlock 获取设备信息完毕回调
/// @param isConnectedBlock 是否连接成功回调，断开连接也从这里回调
- (void)connect:(FEPeripheral *)peripheral server:(void(^)(FEPeripheral *peripheral))serverFinishBlock deviceInfo:(void(^)(FEPeripheral *peripheral, FEDeviceInfo *deviceInfo))deviceInfoBlock isConnected:(void(^)(FEPeripheral *peripheral, BOOL isConnected))isConnectedBlock;
- (void)connect:(FEPeripheral *)peripheral isConnected:(void(^)(FEPeripheral *peripheral, BOOL isConnected))isConnectedBlock;

/// 连接设备进入指令模式
/// @param peripheral 设备
/// @param isConnectedBlock 是否连接成功回调，断开连接也从这里回调
- (void)connectModify:(FEPeripheral *)peripheral isConnected:(void(^)(FEPeripheral *peripheral, BOOL isConnected))isConnectedBlock;

/// 连接设备进入空中升级模式
/// @param peripheral 设备
/// @param isConnectedBlock 是否连接成功回调，断开连接也从这里回调
- (void)connectDFUWithFactory:(BOOL)isFactory peripheral:(FEPeripheral *)peripheral isConnected:(void(^)(FEPeripheral *peripheral, BOOL isConnected))isConnectedBlock;

/// 断开设备
/// @param peripheral 设备
- (void)disconnect:(FEPeripheral *)peripheral;

/// 清空设备列表（scanPeripherals 的数据）
- (void)clear;

/// 连接状态回调（根据需要使用）
/// @param stateChangeBlock 状态回调
- (void)callBackConnectStateChange:(void(^)(FEPeripheral *peripheral))stateChangeBlock;

/// 获取当前WiFi的名称
+ (NSString *)getCurrentWiFiSSID;

/// 获取当前WiFi的MAC地址
+ (NSString *)getCurrentBSSID;

/// 快速配网，IPAddress为nil表示配网失败
- (void)fastConfigNetworkWithSSID:(NSString *)SSID BSSID:(NSString *)BSSID password:(NSString *)password completion:(void (^)(NSString * _Nullable IPAddress))handler;

/// 取消快速配网
- (void)cancelFastConfigNetwork;

@end
