//
//  FEPeripheral.h
//  FEBluetoothSDK
//
//  Created by ericj on 2020/5/20.
//  Copyright © 2020 Feasycom. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "FEDeviceInfo.h"

typedef NS_ENUM(NSInteger, FEPeripheralSendState) {
    FEPeripheralSendState_defalut = 0,
    FEPeripheralSendState_sending,
};

typedef NS_ENUM(NSInteger, FEConnectType) {
    FEConnectType_defalut = 0,  // 一般通讯
    FEConnectType_setting,      // 修改设备信息
    FEConnectType_dfu,          // 空中升级
};

NS_ASSUME_NONNULL_BEGIN

@interface FEPeripheral : NSObject<CBPeripheralDelegate>
/// 设备信息
@property (nonatomic, strong, nullable) FEDeviceInfo* deviceInfo;
/// 蓝牙目标对象
@property (nonatomic, strong) CBPeripheral* peripheral;
/// 信号值
@property (nonatomic, strong) NSNumber* rssi;
/// 广播内容对象
@property (nonatomic, strong) NSDictionary* advertisementData;
/// 连接类型
@property (nonatomic) FEConnectType connectType;
/// 带回应写
@property (nonatomic, strong, nullable) CBCharacteristic* characteristic_write;
/// 不带回应写
@property (nonatomic, strong, nullable) CBCharacteristic* characteristic_write_without_response;
/// 已监听的特征(仅用于修改设备信息)
@property (nonatomic, strong, nullable) CBCharacteristic* notifyCharacteristic;
/// 指定mtu大小
@property (nonatomic) NSInteger mtu_response;
@property (nonatomic) NSInteger mtu_noResponse;
/// 发送状态
@property (nonatomic, readonly) FEPeripheralSendState sendState;

// MARK: 附加项，可用可不用
/// 发送数量
@property (nonatomic) NSInteger sendCount;
/// 接收数量
@property (nonatomic) NSInteger receiveCount;
/// 发送时间
@property (nonatomic) NSTimeInterval sendTimeInterval;
/// 接收crc32
@property (nonatomic) NSInteger crc32_re;
/// 发送crc32
@property (nonatomic) NSInteger crc32_se;

/// 是否允许使用facp2
@property (nonatomic) BOOL isEnableFacp2;

// MARK: 辅助变量（用户随意自定义使用）
@property (nonatomic, strong) id other;

- (instancetype)initWithPeripheral:(CBPeripheral *)peripheral rssi:(NSNumber *)rssi advertisementData:(NSDictionary *)advertisementData;

/// 连接状态回调
/// @param statusBlock 状态回调
- (CBPeripheralState)callbackConnectStatus:(void(^ _Nullable)(CBPeripheralState state))statusBlock;

/// 扫完服务回调
/// @param serverFinishBlock 服务回调
/// @param deviceInfoBlock 设备信息回调
- (void)serverFinishCallback:(void(^ _Nullable)(FEPeripheral *peripheral))serverFinishBlock deviceInfo:(void(^ _Nullable)(FEPeripheral *peripheral, FEDeviceInfo *deviceInfo))deviceInfoBlock;

/// 连接完毕回调（如果含facp2,则处理完 facp2 协议）
/// @param connectFinishBlock 回调
- (void)connectFinishCallback:(void(^ _Nullable)(FEPeripheral *peripheral))connectFinishBlock;

/// 获取设备信息
/// @param deviceInfoBlock 设备信息回调
- (void)readDeviceInfo:(void(^)(FEPeripheral *peripheral, FEDeviceInfo* deviceInfo))deviceInfoBlock;

/// 发送数据
/// @param data 发送的数据（nil表示继续发送）
/// @param isResponse 是否带反馈（默认不带反馈）
/// @param sendBlock 发送回调（"error"发送错误信息，发送成功为nil。"pause"表示是否暂停。"finish"表示是否发送完毕）
- (void)send:(NSData * _Nullable)data withResponse:(BOOL)isResponse complete:(void(^)(FEPeripheral* peripheral, NSError* _Nullable error, BOOL pause, BOOL finish))sendBlock;

/// 暂停发送
- (void)pauseSend;

/// 停止发送
- (void)stopSend;

/// 继续发送
/// @param data 继续发送的数据再加入的数据
- (void)continueSendAddData:(NSData * _Nullable)data;

/// 清除记录(清除附加项数据)
- (void)clear;

/// 接收回调
/// @param filtrationReBlock 过滤条件
/// @param receiveBlock 已过滤的数据（YES:过滤  NO:通过）
- (void)callBackWithReceiveFiltrationBlock:(BOOL(^)(FEPeripheral* peripheral))filtrationReBlock receiveBlock:(void(^)(FEPeripheral* peripheral, CBCharacteristic* characteristic, NSError* _Nullable error))receiveBlock;
- (void)callBackWithReceiveBlock:(void(^)(FEPeripheral* peripheral, CBCharacteristic* characteristic, NSError* _Nullable error))receiveBlock;

/// 读取连接状态，在connectStatus回调
- (void)readConnectStatus;

/// 是否开启facp2，默认开启
/// @param enable 是否开启
- (void)enableFacp2:(BOOL)enable;

/// 其他指令
- (void)otherCode:(NSString *)code;

/// 蓝牙配网，IPAddress为nil表示失败，返回值为NO表示上一次配网尚未完成
- (BOOL)bluetoothConfigNetworkWithName:(NSString *)name password:(NSString *)pwd completion:(void (^)(NSString * _Nullable IPAddress))handler;

/// 查询IP地址，IPAddress为nil表示查询失败，返回值为NO表示正在查询
- (BOOL)queryIPAddressWithHandler:(void (^)(NSString * _Nullable IPAddress))handler;

/// 查询版本号，version为nil表示查询失败，返回值为NO表示正在查询
- (BOOL)queryVersionWithHandler:(void (^)(NSString * _Nullable version))handler;

/// 通过IP地址升级，返回值为NO表示正在升级
- (BOOL)otaUpgradeWithIPAddress:(NSString *)IPAddress completion:(void (^)(BOOL succeeded))handler;

/// 通过固件升级，返回值为NO表示正在升级
- (BOOL)otaUpgradeWithFirmware:(NSString *)firmwareName completion:(void (^)(BOOL succeeded))handler;

/// 恢复出厂设置
- (void)restore;

@end

NS_ASSUME_NONNULL_END
