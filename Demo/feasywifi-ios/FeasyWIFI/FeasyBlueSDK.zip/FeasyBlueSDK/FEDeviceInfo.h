//
//  FEDeviceInfo.h
//  FEBluetoothSDK
//
//  Created by ericj on 2020/5/22.
//  Copyright © 2020 Feasycom. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

// 模块类型
typedef NS_ENUM(NSInteger, MODULE_TYPE) {
    MODULE_TYPE_UNKNOWN,         // 未知类型
    MODULE_TYPE_BLE,             // ble
    MODULE_TYPE_BEACON,          // beacon
};

// 协议类型
typedef NS_ENUM(NSInteger, PROTOCOLTYPE) {
    PROTOCOLTYPE_UNKNOWN,       // 未知协议
    PROTOCOLTYPE_DEFAULT,       // 通用协议
    PROTOCOLTYPE_FACP2,         // FACP2
};

NS_ASSUME_NONNULL_BEGIN

@interface FEDeviceInfo : NSObject
/**设备名*/
@property (nonatomic, strong) NSString* name;
/**设备mac地址*/
@property (nonatomic, strong) NSString* mac;
/**设备硬件版本*/
@property (nonatomic, strong) NSString* device_version;
/**设备软件版本*/
@property (nonatomic, strong) NSString* system_version;
/**设备厂家*/
@property (nonatomic, strong) NSString* owner;
/**模块类型*/
@property (nonatomic) MODULE_TYPE moduleType;
/**协议类型*/
@property (nonatomic) PROTOCOLTYPE protocolType;
/// 设备信息特征
@property (nonatomic, strong) CBCharacteristic *characteristic;


/**读取信息*/
- (void)infoFromCharacteristic:(CBCharacteristic *)characteristic localName:(NSString * _Nullable)localName;


@end

NS_ASSUME_NONNULL_END
